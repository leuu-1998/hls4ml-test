//Numpy array shape [8]
//Min -0.063748516142
//Max 0.118335269392
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
conv2d_1_bias_t b2[8];
#else
conv2d_1_bias_t b2[8] = {-0.0059703789, -0.0113008767, -0.0637485161, 0.1183352694, -0.0374332480, -0.0076922523, -0.0026263441, -0.0042983829};
#endif

#endif
