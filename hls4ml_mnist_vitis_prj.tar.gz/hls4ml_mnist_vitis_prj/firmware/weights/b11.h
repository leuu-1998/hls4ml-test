//Numpy array shape [10]
//Min -0.155333340168
//Max 0.076937325299
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
dense_2_bias_t b11[10];
#else
dense_2_bias_t b11[10] = {0.0376876928, 0.0769373253, 0.0557456054, -0.1553333402, -0.0676670745, -0.0675885603, 0.0577293262, 0.0047399192, 0.0679671839, -0.0164767019};
#endif

#endif
